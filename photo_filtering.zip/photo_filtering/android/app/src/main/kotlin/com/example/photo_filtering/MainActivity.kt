package com.example.photo_filtering

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
