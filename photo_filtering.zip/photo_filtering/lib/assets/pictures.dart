String cat = 'images/cat.jpg';

