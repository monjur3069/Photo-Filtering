import 'package:flutter/material.dart';

const txtWhite = TextStyle(fontSize: 18,color: Colors.white);